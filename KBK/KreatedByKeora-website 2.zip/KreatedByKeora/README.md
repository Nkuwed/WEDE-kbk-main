# KreatedByKeora — Website

Front-end build for **KreatedByKeora**, a nail artistry studio based in
Kibler Park, Johannesburg South. Built to match the approved WEDE5020
Website Project Proposal (Part 1) and its low-fidelity wireframes, with
a Gallery page added at the client's request.

## Structure

```
KreatedByKeora/
├── index.html            Homepage — hero, quick categories, featured/popular nail art
├── about.html             About Us — Keora's story, background, mission & vision
├── services.html          Services — filterable price list with portfolio images
├── gallery.html           Gallery — full portfolio, filterable, with a lightbox
├── enquiry.html            Booking form — validated client-side, policies, POPIA note
├── contact.html            Map, WhatsApp/call, socials, small contact form
├── css/
│   └── style.css          Design tokens, layout, components, gallery + lightbox styles
├── js/
│   ├── main.js             Mobile nav drawer, category filter, lightbox, active nav state
│   └── form-validation.js  Required-field / email / phone validation
├── images/
│   ├── hero/               Logo
│   ├── portfolio/          Nail art photography (17 real studio shots)
│   └── icons/               (reserved for future iconography)
└── README.md
```

## Design system

- **Colour:** blush pink (`#f1c4d6`) and rose-gold (`#c79a7b`) on a
  charcoal base (`#18131a`), per the proposal's Design & UX brief.
- **Type:** Fraunces (serif, headings) paired with Manrope (sans-serif,
  body/UI).
- **Layout:** mobile-first, single column, with a sticky top header and
  a sticky bottom thumb-nav bar for one-handed browsing — the desktop
  breakpoint (≥860px) swaps in a conventional top nav.

## Gallery

`gallery.html` shows all 17 portfolio photos in a filterable grid (All /
Nail Art / Gel-X / Manicures) with a click-to-enlarge lightbox. It's
linked from the top nav, mobile drawer, bottom tab bar, and the
homepage's "Featured" and "Popular" sections.

## Contact details (live)

- **Instagram:** [@kreatedbykeora](https://www.instagram.com/kreatedbykeora/)
- **TikTok:** [@kreatedbykeora](https://www.tiktok.com/@kreatedbykeora)
- **WhatsApp / call:** +27 82 095 1275

These are wired into the footer on every page, the contact page's
click-to-chat and click-to-call buttons, and the social links.

## Notes

- Forms are validated client-side only (no backend/API yet) — this
  matches the Part 1/2 scope in the proposal timeline; server-side
  handling and JavaScript enhancements continue in Part 3.
- All portfolio photography is the studio's own work, supplied by the
  client.
- The contact page map uses a keyless Google Maps embed centred on
  Kibler Park; replace with the exact studio address once available.
