/* ==========================================================================
   KreatedByKeora — main.js
   Mobile nav drawer + services category filter.
   ========================================================================== */

(function () {
  "use strict";

  /* ---- Mobile drawer menu ---- */
  var openBtn = document.querySelector("[data-menu-open]");
  var closeBtn = document.querySelector("[data-menu-close]");
  var drawer = document.querySelector("[data-drawer]");

  function openDrawer() {
    if (!drawer) return;
    drawer.classList.add("open");
    openBtn && openBtn.setAttribute("aria-expanded", "true");
    document.body.style.overflow = "hidden";
  }

  function closeDrawer() {
    if (!drawer) return;
    drawer.classList.remove("open");
    openBtn && openBtn.setAttribute("aria-expanded", "false");
    document.body.style.overflow = "";
  }

  if (openBtn) openBtn.addEventListener("click", openDrawer);
  if (closeBtn) closeBtn.addEventListener("click", closeDrawer);
  if (drawer) {
    drawer.addEventListener("click", function (e) {
      if (e.target === drawer) closeDrawer();
    });
  }
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape") closeDrawer();
  });

  /* ---- Category filter (services.html and gallery.html) ---- */
  var filterRow = document.querySelector("[data-filter-row]");
  var grid = document.querySelector("[data-service-grid]");
  var emptyState = document.getElementById("empty-state");

  if (filterRow && grid) {
    var chips = filterRow.querySelectorAll(".chip");
    var cards = grid.querySelectorAll(".service-card, .g-item");

    filterRow.addEventListener("click", function (e) {
      var chip = e.target.closest(".chip");
      if (!chip) return;

      chips.forEach(function (c) { c.classList.remove("active"); });
      chip.classList.add("active");

      var filter = chip.getAttribute("data-filter");
      var visibleCount = 0;

      cards.forEach(function (card) {
        var match = filter === "all" || card.getAttribute("data-category") === filter;
        card.style.display = match ? "" : "none";
        if (match) visibleCount++;
      });

      if (emptyState) {
        emptyState.style.display = visibleCount === 0 ? "block" : "none";
      }
    });
  }

  /* ---- Lightbox (gallery.html) ---- */
  var lightbox = document.querySelector("[data-lightbox]");
  if (lightbox) {
    var lbImg = lightbox.querySelector("[data-lightbox-img]");
    var lbCaption = lightbox.querySelector("[data-lightbox-caption]");
    var lbClose = lightbox.querySelector("[data-lightbox-close]");
    var items = document.querySelectorAll(".g-item");

    function openLightbox(src, caption) {
      lbImg.src = src;
      lbImg.alt = caption || "";
      lbCaption.textContent = caption || "";
      lightbox.classList.add("open");
      document.body.style.overflow = "hidden";
    }
    function closeLightbox() {
      lightbox.classList.remove("open");
      document.body.style.overflow = "";
    }

    items.forEach(function (item) {
      item.addEventListener("click", function () {
        openLightbox(item.getAttribute("data-full"), item.getAttribute("data-caption"));
      });
    });
    if (lbClose) lbClose.addEventListener("click", closeLightbox);
    lightbox.addEventListener("click", function (e) {
      if (e.target === lightbox) closeLightbox();
    });
    document.addEventListener("keydown", function (e) {
      if (e.key === "Escape") closeLightbox();
    });
  }

  /* ---- Fallback: highlight active tab/nav link by current page ---- */
  var current = window.location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".tab-bar a, .top-links a").forEach(function (link) {
    var href = link.getAttribute("href");
    if (href === current) link.classList.add("active");
  });

})();
