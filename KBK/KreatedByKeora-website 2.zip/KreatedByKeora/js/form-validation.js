/* ==========================================================================
   KreatedByKeora — form-validation.js
   Client-side validation for the booking (enquiry) and contact forms.
   Required fields, valid email format, valid SA-style phone number.
   ========================================================================== */

(function () {
  "use strict";

  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  /* Accepts 10-digit local numbers (082 123 4567) or +27 international format,
     with optional spaces/dashes. */
  var PHONE_RE = /^(\+27|0)[\s-]?\d{2}[\s-]?\d{3}[\s-]?\d{4}$/;

  function showError(field, show) {
    field.classList.toggle("invalid", show);
  }

  function validateField(input) {
    var field = input.closest(".field");
    if (!field) return true;

    var value = input.value.trim();
    var valid = true;

    if (input.hasAttribute("required") && value === "") {
      valid = false;
    } else if (input.type === "email" && value !== "" && !EMAIL_RE.test(value)) {
      valid = false;
    } else if (input.type === "tel" && value !== "" && !PHONE_RE.test(value)) {
      valid = false;
    }

    showError(field, !valid);
    return valid;
  }

  function wireForm(formId, successId) {
    var form = document.getElementById(formId);
    if (!form) return;

    var success = document.getElementById(successId);
    var inputs = form.querySelectorAll("input, select, textarea");

    inputs.forEach(function (input) {
      input.addEventListener("blur", function () { validateField(input); });
      input.addEventListener("input", function () {
        var field = input.closest(".field");
        if (field && field.classList.contains("invalid")) validateField(input);
      });
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();

      var allValid = true;
      inputs.forEach(function (input) {
        if (!validateField(input)) allValid = false;
      });

      if (!allValid) {
        var firstInvalid = form.querySelector(".field.invalid input, .field.invalid select, .field.invalid textarea");
        if (firstInvalid) firstInvalid.focus();
        if (success) success.classList.remove("show");
        return;
      }

      /* No backend is wired up yet — Part 1/2 scope is front-end only.
         Confirm success in-page and reset the form. */
      if (success) success.classList.add("show");
      form.reset();
    });
  }

  wireForm("booking-form", "form-success");
  wireForm("contact-form", "contact-success");

})();
